+++
title = "1871.studio | À propos"
date = 2019-11-27
[extra]
h1 = "Pourquoi 1871 ? Qui suis-je ?"
+++

## Quelques loisirs pertinents
<div class="fk-grid fk-4col">

**🥋 Aïkido**
bienveillance, entraide &&nbsp;harmonie

**🎲 Jeux de plateaux**
stratégie, réflexion &&nbsp;logique

**🎸 Rock saturé**
énergie, conscience sociale &&nbsp;politique

**🇳🇴 Norvégien**
originalité, curiosité &&nbsp;challenge

</div>

<div class="fk-grid fk-2col">

### Des choses que j'aime mais que généralement les autres n'aiment pas
<ul class="yes">
    <li>Le catch</li>
    <li>Le DrPepper</li>
    <li>Le pop-punk</li>
    <li>La salade alaska⁽⁴⁾</li>
    <li>Les teen movies⁽⁵⁾</li>
</ul>

### Des choses que les gens aiment en général mais pas moi</h3>
<ul class="nope">
    <li>Le café</li>
    <li>L'alcool</li>
    <li>Web3⁽⁶⁾ - NFTs - cryptos</li>
    <li>Le chocolat</li>
    <li>La Nouvelle Vague⁽⁷⁾</li>
</ul>
</div>