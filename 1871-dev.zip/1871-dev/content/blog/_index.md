+++
title = "1871.studio | Le Blog"
paginate_by = 6
sort_by = "date"
template = "archive.html"
page_template = "post.html"
insert_anchor_links = "right"
[extra]
h1 = "Le blog design et numérique"
+++