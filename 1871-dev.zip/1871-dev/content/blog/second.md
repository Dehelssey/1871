+++
title = "1871.studio | Web3 vs Web0"
description = "lorem ipsum"
date = 2021-03-27
insert_anchor_links = "right"
[taxonomies]
tags = ["Web", "Décentralisation"]
[extra]
h1 = "Pourquoi je choisis le web0 plutôt que le web3"
image = "https://picsum.photos/300/400"
+++

This is my first project.
## Contexte

comment on met des classes en markdown ?

### blablabla

### lorem ipsum

comment on met des classes en markdown ?

### eh ouais

## Solution

[test](#)

<a class="fk-button">test</a>