+++
title = "1871.studio | Mentions Légales"
date = 2019-11-27
[extra]
h1 = "Mentions Légales"
+++
(On sait que personne ne les lit parce que c'est ~~chiant~~ un peu ennuyeux, mais bon il faut les rédiger quand même !)

## Informations
Guérin Delacommune  \
[hello@1871.studio](mailto:hello@1871.studio)  \
SIRET : 539 087 544 00026  \
[Je suis sur Linkedin](https://www.linkedin.com/in/concepteur-numerique)

## Données personnelles
Afin d'être en parfaite conformité RGPD, ce site ne ~~vous espionne pas~~ récolte pas vos données et ne dépose aucun cookie sur votre appareil *(désolé les gourmand·es)*.

## Crédits
### Illustrations, web design & développement
[1871.studio](https://1871.studio) grâce à [Penpot](https://penpot.app), [Figma](https://www.figma.com) & [Zola](https://www.getzola.org)

### Hébergement
[Infomaniak Network SA](https://www.infomaniak.com)  \
Rue Eugène Marziano 25  \
1227 Les Acacias (GE)  \
(Suisse)

## Copyleft
Le présent site constitue une oeuvre dont Guérin Delacommune est l’auteur au sens des [articles L.111-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042814694) et suivants du Code de la propriété intellectuelle.

L'ensemble des éléments de ce site (logos, charte graphique, illustrations, graphismes et contenus textuels) sont sous [licence GPL v3](https://opensource.org/licenses/gpl-3.0.html), et peuvent être donc être modifiés, réutilisés et reproduits librement, tant que le projet final conserve cette même licence.

C'est ça le **#copyleft**