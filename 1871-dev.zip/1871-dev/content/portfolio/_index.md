+++
title = "1871.studio | Portfolio"
paginate_by = 6
sort_by = "date"
template = "archive.html"
page_template = "post.html"
insert_anchor_links = "right"
[extra]
h1 = "Des projets dont je suis fier"
+++