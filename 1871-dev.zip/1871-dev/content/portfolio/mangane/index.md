+++
title = "1871.studio | Bdx.town"
description = "Une alternative aux réseaux sociaux centralisés"
date = 2021-01-29
[taxonomies]
tags = ["PWA", "UX Design"]
[extra]
h1 = "Mangane"
image = "https://picsum.photos/300/400"
+++

Clovis, la personne à l’origine du projet, a sollicité mon aide pour améliorer l’expérience proposée aux utilisateur·ices de BDX.town. 
Même si nous partions d’une base graphique et fonctionnelle existante, nous avions tous deux l’envie d’aller plus loin et de proposer des fonctionnalités non présente afin de faciliter la prise en main et l’adoption de ce réseau décentralisé

## Contexte

[BDX.town](https://BDX.town) est un réseau social local ouvert sur le reste du monde, sans pub, sans marchandisation des données personnelles.

C’est un espace d'échange et d'entraide local pour les artistes, les créateurs, les artisans de Bordeaux et ses alentours.

En plus d’un fil chronologique des gens que vous suivez, vous avez accès à un fil regroupant toutes les personnes de [bdx.town](https://bdx.town) ainsi qu’un troisième, regroupant nos “voisins” en ligne.

En effet, BDX.town fait partie du fediverse [<span id="text-note1">⁽¹⁾</span>](#note1) (Federated Universe), fort de 2M+ d’utilisateurs. Nous n’évoluons donc pas en vase clos.

## Annuaire des membres

Pour faciliter la découverte de profils intéressants à suivre sur ce nouveau réseau local, nous souhaitons que Mangane propose un annuaire des membres. Mastodon et Misskey, deux autres logiciels similaires du fediverse en proposent et leur utilité n’est plus à démontrer. 

### Veille “concurrentielle”

Avant d’aller voir ce qui se fait ailleurs, récapitulons ce qui se fait déjà à l’heure actuelle sur l’interface Mangane. Ces “cartes” serviront de référence pour l’annuaire.


{% set image = resize_image(path=path, width=width, height=height, op=op) %}
{% include image.html url="/images/my-cat.jpg" description="My cat, Robert Downey Jr." %}

![Vue du profil perso sur la page d’accueil](https://user-images.githubusercontent.com/20315413/127572376-21a9a333-9180-467e-bdad-8eaa3d198044.png)

Vue du profil perso sur la page d’accueil

![Vue d’un profil au survol de l’avatar d’une personne sur un fil](https://user-images.githubusercontent.com/20315413/127572386-896356cf-8d58-4991-8c2a-5f181587b63a.png)

Vue d’un profil au survol de l’avatar d’une personne sur un fil


➡️ Rapidement le sentiment que le nombre d'abonné·e·s et d'abonnements *ne sont pas des datas utiles pour décider ou non de suivre une personne* s’impose à moi.



Le nombre de publications est un indicateur (on peut rechercher des gens qui publient souvent, ou à l’inverse fuir les trop “bavards”) mais il n'est pertinent qu'avec une date d'inscription afin d’obtenir une fréquence.

Idéalement, il faudrait n’afficher que cette fréquence, la plus utile, pour alléger l’interface.


⚠️ Bémol cependant : un utilisateur inscrit depuis longtemps qui n’aurait commencé que récemment à publier beaucoup présenterait une fréquence faussée.
Mais la donnée se stabiliserait sur la durée.



#### Mastodon

Au premier abord Mastodon propose sensiblement les mêmes infos : bannière, photo de profil, bio, nombre de publications et d’abonné.

Le logiciel se démarque en proposant la donnée **"dernière activité"** qui permettrait justement de mieux jauger la “vivacité” d’un compte et éviter de suivre un profil inutilisé...

![Untitled](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Untitled.png)

Sur son annuaire Mastodon propose des vues filtrables (actifs récemment ou nouveaux arrivés, profils locaux ou fédérés.)

![https://user-images.githubusercontent.com/20315413/127573040-87ab3b91-a1c2-4b29-8c60-d2392b769310.png](https://user-images.githubusercontent.com/20315413/127573040-87ab3b91-a1c2-4b29-8c60-d2392b769310.png)

#### Misskey

Misskey propose exactement les mêmes informations que Mangane, bannière, avatar, bio, nombre de publications, d’abonnés & d’abonnements.

![https://user-images.githubusercontent.com/20315413/127573010-8d1520d9-5f0f-4431-a213-f7a51d2b57b0.png](https://user-images.githubusercontent.com/20315413/127573010-8d1520d9-5f0f-4431-a213-f7a51d2b57b0.png)

L’annuaire Misskey propose des “utilisateur·ices épinglé·es”, soit une sélection des admins de l’instance.

![Untitled](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Untitled%201.png)

### Ma proposition

Compte-tenu de ces différentes considérations j’ai entamé une phase d’itération du rendu.
L’interface étant déjà en ligne, et la structure assez simple, j’ai maquetté directement en rendu “final” en modifiant les éléments dans l’inspecteur ou en recréant certains composant sur Xd afin de rapidement me rendre compte de l’efficacité ou non des différentes mises en page.

![https://user-images.githubusercontent.com/20315413/127573458-9c02194a-056a-4555-ac6b-1aaa67934f56.png](https://user-images.githubusercontent.com/20315413/127573458-9c02194a-056a-4555-ac6b-1aaa67934f56.png)

Par rapport à la carte utilisateur par défaut, j’ai supprimé les données inutiles, on a donc gardé le nombre de messages et la dernière activité.

![https://user-images.githubusercontent.com/20315413/127573519-dec76c7c-5f96-46d1-89f8-cdb4f9c45c7e.png](https://user-images.githubusercontent.com/20315413/127573519-dec76c7c-5f96-46d1-89f8-cdb4f9c45c7e.png)

une déclinaison de mon premier jet en allégeant la construction nom affiché / @pseudo sur une seule ligne.


⚠️ **problème :** certaines personnes ont un nom affiché qui diffère du @pseudo



J’ai également envisager d’afficher le statut en ligne / hors ligne plutôt que le nombre de messages mais l’information faisait un peu doublon avec la dernière activité. En plus d’être peu pertinente dans la décision ou non de suivre un compte.

![Groupe 61.png](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Groupe_61.png)

Une autre piste, plus vertueuse peut-être, m’est alors venue en tête : supprimer carrément toute la data et ne reposer sa décision que sur la bio de la personne.

![https://user-images.githubusercontent.com/20315413/127573822-846b79de-04a9-40d7-8d98-68cb642a15a6.png](https://user-images.githubusercontent.com/20315413/127573822-846b79de-04a9-40d7-8d98-68cb642a15a6.png)

Une version minimaliste donc, pour éviter la course aux métriques et l’effet boule de neige des “gros” comptes qui grossissent encore.

Une version qui me plaisait bien et que j’aurais probablement proposée mais...

*car il y a un mais.*

![Un utilisateur avec une très courte bio](https://user-images.githubusercontent.com/20315413/127573888-97e49f23-0677-492c-b65c-aebab2d7e1de.png)

Un utilisateur avec une très courte bio

Le rendu est très vide si l'utilisateur a une mini bio et pire encore s’il n’a aucune bio renseignée.


➡️ L’hypothèse d’une construction en *masonry* avec des cartes de profils à hauteur variable s’est posée. Cependant pour une meilleure lisibilité le choix de rester sur une grille régulière à hauteur fixe.



Mon choix final s’est donc porté sur ma première version. En effet la présence de la data considérée comme pertinente casse l’impression de vide dans le cas d’une bio minimale ou absente

![https://user-images.githubusercontent.com/20315413/127573458-9c02194a-056a-4555-ac6b-1aaa67934f56.png](https://user-images.githubusercontent.com/20315413/127573458-9c02194a-056a-4555-ac6b-1aaa67934f56.png)

![Groupe 29.png](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Groupe_29.png)

![Groupe 26.png](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Groupe_26.png)

![le rendu final proposé en situation sur ordinateur](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/ANNUAIRE_V2.png)

le rendu final proposé en situation sur ordinateur

![et sur mobile](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Samsung_Galaxy_S10__1.png)

et sur mobile

Mise à jour : l’UI de [bdx.town](https://bdx.town) a évolué, j’ai donc légèrement revu ma copie pour l’annuaire de membres.

[https://www.figma.com/proto/lOmoWp7cuw14qYPvZuoCFs/BDX.town---Design?node-id=3%3A1023&viewport=59%2C777%2C0.47&scaling=scale-down-width&page-id=0%3A1&starting-point-node-id=3%3A1023](https://www.figma.com/proto/lOmoWp7cuw14qYPvZuoCFs/BDX.town---Design?node-id=3%3A1023&viewport=59%2C777%2C0.47&scaling=scale-down-width&page-id=0%3A1&starting-point-node-id=3%3A1023)

## Accueil des nouveaux membres

À la manière de ce que proposait Mastodon, nous souhaitons mettre en place un petit “*onboarding*” pour aider les nouveaux arrivants à facilement trouver leurs repère sur l’interface de [BDX.town](https://BDX.town) (Mangane, de son petit nom).

### Veille “concurrentielle”

Seul Mastodon proposait un onboarding à l’inscription sur une instance. Il expliquait le principe des instances (qui diffère des réseaux sociaux “classiques” centralisés), et les différents fils d’actualités qu’on peut consulter.

![Dans ses premières versions, il expliquait le fonctionnement du @pseudo@instance (par opposition au @pseudo simple de Twitter)](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Untitled%202.png)

Dans ses premières versions, il expliquait le fonctionnement du @pseudo@instance (par opposition au @pseudo simple de Twitter)

![La dernière version, dans l’optique de réduire le nombre d’étapes à l’onboarding, avait supprimé cette information](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Untitled%203.png)

La dernière version, dans l’optique de réduire le nombre d’étapes à l’onboarding, avait supprimé cette information

![Untitled](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Untitled%204.png)

![Untitled](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Untitled%205.png)

Cependant son utilité réelle restait discutable : quel besoin de rappeler le nom du serveur sur lequel on vient de se créer un compte ? Y a-t-il réellement besoin d’expliquer qu’on peut répondre, partager et mettre en favori les contenus présentés ?

Cet onboarding est, depuis l’an dernier, remplacé par un email qui renvoie vers quelques pages de réglages et configuration.

### Ma proposition

J’ai alors commencé à lister les différents éléments qu’on pouvait inclure dans l’onbording de Mangane avant de les trier par ordre d’importance. J’ai ainsi pu décider quelles infos restaient et lesquelles n’étaient pas indispensables afin d’ordonner les différents écrans de l’onboarding sans le surcharger.


<div class="fk-flex">
<div class="fk-col">

**✅ nécessaire**

- explication du @pseudo
- présentation des fils
- possibilité de passer
- possibilité de revoir l’onboarding dans l'UI
</div>
<div class="fk-col">

**👍 pertinent**

- rappel du code de conduite de BDX.town
- suggestions de comptes à suivre
- options de confidentialité (compte public ou privé)

</div>
<div class="fk-col">

**❓ secondaire**

- présentation du mode *chat*
- présenter les réglages avancés
- présenter les options de confidentialité
</div>
</div>

Dans une volonté de ne pas imposer un *onboarding* trop long, ma proposition s’est arrêté sur **4 étapes** :

1. Bienvenue → explications de l’interconnexion entre les instances à la manière des emails + rappel du nom d’utilisateur complet @pseudo@instance
2. Présentation des timelines → le fil personnel (les gens suivis), le fil local (”bdx.town” pour les gens de la même instance) et le fil fédéré (”découvrir”, pour les voisins)
3. Rappel des grandes lignes du code de conduite avec demande d’acceptation
4. Présentation des options de confidentialité → définir si le profil publie en public ou en privé, si les gens peuvent s’abonner sans confirmation, si le profil est répertorié sur l’instance et sur les moteurs de recherche.

![Schémas de Clovis](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Untitled%206.png)

Schémas de Clovis

![Untitled](BDX%20town%2051f581c0785948d6aeffb6a2ac4ba8b5/Untitled%207.png)

[https://www.figma.com/proto/lOmoWp7cuw14qYPvZuoCFs/BDX.town---Design?node-id=7%3A1198&viewport=-92%2C262%2C0.16&scaling=min-zoom&page-id=0%3A1&starting-point-node-id=7%3A1198](https://www.figma.com/proto/lOmoWp7cuw14qYPvZuoCFs/BDX.town---Design?node-id=7%3A1198&viewport=-92%2C262%2C0.16&scaling=min-zoom&page-id=0%3A1&starting-point-node-id=7%3A1198)

*Design final - Work in progress [en attente des illustrations finales]*

Enfin, en suivant l’exemple de Mastodon depuis 2021, plutôt que d’emmener les utilisateurs sur une timeline vide à leur inscription, nous avons souhaité les diriger vers une liste de profils à suivre.

<section class="notes">

## Notes {.fk-accent}

<p id="note1">1. Imaginez pouvoir suivre un compte instagram avec votre compte twitter ? Ou commenter une vidéo youtube avec votre profil facebook ? Sur le fediverse c’est “possible” : sauf que vos plateformes habituelles n’ont pas le même nom.<br><br>Un compte Mangane sur bdx.town vous permet par exemple d’interagir avec les vidéos postées sur PeerTube, les photos partagées sur PixelFed, les blogs écrits sous Plume ou WriteFreely ou même les évènements organisés sur Mobilizon. <a href="#text-note1">U</a></p>
</section>