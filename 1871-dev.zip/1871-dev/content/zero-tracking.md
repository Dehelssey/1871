+++
title = "1871.studio | Confidentialité"
date = 2019-11-27
[extra]
h1 = "Je ne vous espionne pas."
+++

**Je respecte votre vie privée.**  \
Même si vous n'avez [rien à cacher](https://www.privacity.fr/blog/je-nai-rien-a-cacher/).

Ce site ne dispose donc d'aucun outil de suivi ou d'analyse de navigation (et surtout pas [ceux de Google](https://degooglisons-internet.org/fr/)).

Ce site ne charge aucune police de caractère distante (vous aussi, [dites non aux Google Fonts](https://bernard-sperandio.fr/google-fonts-rgpd/)).

Ce site ne propose aucun [bouton-espion](https://www.blogdumoderateur.com/comment-facebook-espionne/) de quelque réseau social que ce soit.

**Bref ce site n'utilise <span class="fk-swipe">aucune technologie pour vous identifier</span>, vous reconnaitre, ni même analyser votre navigation.**